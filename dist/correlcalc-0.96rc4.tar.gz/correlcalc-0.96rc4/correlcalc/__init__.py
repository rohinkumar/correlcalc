__author__ = 'Rohin Kumar Y'
# import numpy as np
# import math as m
# from scipy import integrate
# from .comovdist import *
# from .metrics import metrics
# from .
import metrics
global Om
global Ol
# global datpath
# global randpath
# global maskpath

from .tpcf import *
# from .antpcf import *
from .datprep import *
from .antpcf import *
from .datvis import *
# try:
#    from correlcalc.metrics import *
# except ImportError:
#    print "correlcalc.metrics ImportError"
# from metrics import *
# from hw import hw
# def version():
#    print "correlcalc version no. 0.93"
