# Set global parameters here related to Cosmology (more to be added)
# Om= matter density Ol=dark energy density at the present epoch
Om = 0.3
Ol = 0.7
